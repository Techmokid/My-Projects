# -*- coding: utf-8 -*-

"""
discord.py extensions
~~~~~~~~~~~~~~~~~~~~~~

Extensions for the discord.py library live in this namespace.

:copyright: (c) 2016 Rapptz
:license: MIT, see LICENSE for more details.

"""
